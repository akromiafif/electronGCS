"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MavDoRepositionFlags = void 0;
var MavDoRepositionFlags;
(function (MavDoRepositionFlags) {
    MavDoRepositionFlags[MavDoRepositionFlags["MAV_DO_REPOSITION_FLAGS_CHANGE_MODE"] = 1] = "MAV_DO_REPOSITION_FLAGS_CHANGE_MODE";
    MavDoRepositionFlags[MavDoRepositionFlags["MAV_DO_REPOSITION_FLAGS_ENUM_END"] = 2] = "MAV_DO_REPOSITION_FLAGS_ENUM_END";
})(MavDoRepositionFlags = exports.MavDoRepositionFlags || (exports.MavDoRepositionFlags = {}));
//# sourceMappingURL=mav-do-reposition-flags.js.map