import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class GpsInjectData extends MAVLinkMessage {
    target_system: number;
    target_component: number;
    len: number;
    data: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=gps-inject-data.d.ts.map