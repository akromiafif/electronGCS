import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class GpsRtcmData extends MAVLinkMessage {
    flags: number;
    len: number;
    data: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=gps-rtcm-data.d.ts.map