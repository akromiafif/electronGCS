export enum MavDoRepositionFlags {
	MAV_DO_REPOSITION_FLAGS_CHANGE_MODE = 1, // The aircraft should immediately transition into guided. This should not be set for follow me applications
	MAV_DO_REPOSITION_FLAGS_ENUM_END = 2, // 
}