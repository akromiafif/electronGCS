import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { MavCollisionSrc } from '../enums/mav-collision-src';
import { MavCollisionAction } from '../enums/mav-collision-action';
import { MavCollisionThreatLevel } from '../enums/mav-collision-threat-level';
export declare class Collision extends MAVLinkMessage {
    src: MavCollisionSrc;
    id: number;
    action: MavCollisionAction;
    threat_level: MavCollisionThreatLevel;
    time_to_minimum_delta: number;
    altitude_minimum_delta: number;
    horizontal_minimum_delta: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=collision.d.ts.map