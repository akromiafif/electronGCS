export declare enum MavBatteryType {
    MAV_BATTERY_TYPE_UNKNOWN = 0,
    MAV_BATTERY_TYPE_LIPO = 1,
    MAV_BATTERY_TYPE_LIFE = 2,
    MAV_BATTERY_TYPE_LION = 3,
    MAV_BATTERY_TYPE_NIMH = 4,
    MAV_BATTERY_TYPE_ENUM_END = 5
}
//# sourceMappingURL=mav-battery-type.d.ts.map