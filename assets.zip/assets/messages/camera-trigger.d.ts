import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class CameraTrigger extends MAVLinkMessage {
    time_usec: number;
    seq: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=camera-trigger.d.ts.map