export declare enum MavCollisionThreatLevel {
    MAV_COLLISION_THREAT_LEVEL_NONE = 0,
    MAV_COLLISION_THREAT_LEVEL_LOW = 1,
    MAV_COLLISION_THREAT_LEVEL_HIGH = 2,
    MAV_COLLISION_THREAT_LEVEL_ENUM_END = 3
}
//# sourceMappingURL=mav-collision-threat-level.d.ts.map