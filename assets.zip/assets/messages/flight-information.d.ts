import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class FlightInformation extends MAVLinkMessage {
    time_boot_ms: number;
    arming_time_utc: number;
    takeoff_time_utc: number;
    flight_uuid: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=flight-information.d.ts.map