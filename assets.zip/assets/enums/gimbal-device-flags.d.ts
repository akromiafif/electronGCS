export declare enum GimbalDeviceFlags {
    GIMBAL_DEVICE_FLAGS_RETRACT = 1,
    GIMBAL_DEVICE_FLAGS_NEUTRAL = 2,
    GIMBAL_DEVICE_FLAGS_ROLL_LOCK = 4,
    GIMBAL_DEVICE_FLAGS_PITCH_LOCK = 8,
    GIMBAL_DEVICE_FLAGS_YAW_LOCK = 16,
    GIMBAL_DEVICE_FLAGS_ENUM_END = 17
}
//# sourceMappingURL=gimbal-device-flags.d.ts.map