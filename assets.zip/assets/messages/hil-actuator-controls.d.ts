import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { MavModeFlag } from '../enums/mav-mode-flag';
export declare class HilActuatorControls extends MAVLinkMessage {
    time_usec: number;
    controls: number;
    mode: MavModeFlag;
    flags: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=hil-actuator-controls.d.ts.map