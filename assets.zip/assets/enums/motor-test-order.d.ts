export declare enum MotorTestOrder {
    MOTOR_TEST_ORDER_DEFAULT = 0,
    MOTOR_TEST_ORDER_SEQUENCE = 1,
    MOTOR_TEST_ORDER_BOARD = 2,
    MOTOR_TEST_ORDER_ENUM_END = 3
}
//# sourceMappingURL=motor-test-order.d.ts.map