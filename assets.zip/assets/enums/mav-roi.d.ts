export declare enum MavRoi {
    MAV_ROI_NONE = 0,
    MAV_ROI_WPNEXT = 1,
    MAV_ROI_WPINDEX = 2,
    MAV_ROI_LOCATION = 3,
    MAV_ROI_TARGET = 4,
    MAV_ROI_ENUM_END = 5
}
//# sourceMappingURL=mav-roi.d.ts.map