import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { GimbalDeviceFlags } from '../enums/gimbal-device-flags';
import { GimbalDeviceErrorFlags } from '../enums/gimbal-device-error-flags';
export declare class GimbalDeviceAttitudeStatus extends MAVLinkMessage {
    time_boot_ms: number;
    flags: GimbalDeviceFlags;
    q: number;
    angular_velocity_x: number;
    angular_velocity_y: number;
    angular_velocity_z: number;
    failure_flags: GimbalDeviceErrorFlags;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=gimbal-device-attitude-status.d.ts.map