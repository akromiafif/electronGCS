export declare enum FenceMitigate {
    FENCE_MITIGATE_UNKNOWN = 0,
    FENCE_MITIGATE_NONE = 1,
    FENCE_MITIGATE_VEL_LIMIT = 2,
    FENCE_MITIGATE_ENUM_END = 3
}
//# sourceMappingURL=fence-mitigate.d.ts.map