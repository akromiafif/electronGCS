import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { GpsFixType } from '../enums/gps-fix-type';
export declare class Gps2Raw extends MAVLinkMessage {
    time_usec: number;
    fix_type: GpsFixType;
    lat: number;
    lon: number;
    alt: number;
    eph: number;
    epv: number;
    vel: number;
    cog: number;
    satellites_visible: number;
    dgps_numch: number;
    dgps_age: number;
    yaw: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=gps2-raw.d.ts.map