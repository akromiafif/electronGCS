import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { MavProtocolCapability } from '../enums/mav-protocol-capability';
export declare class AutopilotVersion extends MAVLinkMessage {
    capabilities: MavProtocolCapability;
    flight_sw_version: number;
    middleware_sw_version: number;
    os_sw_version: number;
    board_version: number;
    flight_custom_version: number;
    middleware_custom_version: number;
    os_custom_version: number;
    vendor_id: number;
    product_id: number;
    uid: number;
    uid2: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=autopilot-version.d.ts.map