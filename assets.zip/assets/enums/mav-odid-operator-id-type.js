"use strict";
exports.__esModule = true;
exports.MavOdidOperatorIdType = void 0;
var MavOdidOperatorIdType;
(function (MavOdidOperatorIdType) {
    MavOdidOperatorIdType[MavOdidOperatorIdType["MAV_ODID_OPERATOR_ID_TYPE_CAA"] = 0] = "MAV_ODID_OPERATOR_ID_TYPE_CAA";
    MavOdidOperatorIdType[MavOdidOperatorIdType["MAV_ODID_OPERATOR_ID_TYPE_ENUM_END"] = 1] = "MAV_ODID_OPERATOR_ID_TYPE_ENUM_END";
})(MavOdidOperatorIdType = exports.MavOdidOperatorIdType || (exports.MavOdidOperatorIdType = {}));
