export declare enum MavOdidHorAcc {
    MAV_ODID_HOR_ACC_UNKNOWN = 0,
    MAV_ODID_HOR_ACC_10NM = 1,
    MAV_ODID_HOR_ACC_4NM = 2,
    MAV_ODID_HOR_ACC_2NM = 3,
    MAV_ODID_HOR_ACC_1NM = 4,
    MAV_ODID_HOR_ACC_0_5NM = 5,
    MAV_ODID_HOR_ACC_0_3NM = 6,
    MAV_ODID_HOR_ACC_0_1NM = 7,
    MAV_ODID_HOR_ACC_0_05NM = 8,
    MAV_ODID_HOR_ACC_30_METER = 9,
    MAV_ODID_HOR_ACC_10_METER = 10,
    MAV_ODID_HOR_ACC_3_METER = 11,
    MAV_ODID_HOR_ACC_1_METER = 12,
    MAV_ODID_HOR_ACC_ENUM_END = 13
}
//# sourceMappingURL=mav-odid-hor-acc.d.ts.map