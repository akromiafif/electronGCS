export declare enum MavOdidIdType {
    MAV_ODID_ID_TYPE_NONE = 0,
    MAV_ODID_ID_TYPE_SERIAL_NUMBER = 1,
    MAV_ODID_ID_TYPE_CAA_REGISTRATION_ID = 2,
    MAV_ODID_ID_TYPE_UTM_ASSIGNED_UUID = 3,
    MAV_ODID_ID_TYPE_ENUM_END = 4
}
//# sourceMappingURL=mav-odid-id-type.d.ts.map