"use strict";
exports.__esModule = true;
exports.FenceMitigate = void 0;
var FenceMitigate;
(function (FenceMitigate) {
    FenceMitigate[FenceMitigate["FENCE_MITIGATE_UNKNOWN"] = 0] = "FENCE_MITIGATE_UNKNOWN";
    FenceMitigate[FenceMitigate["FENCE_MITIGATE_NONE"] = 1] = "FENCE_MITIGATE_NONE";
    FenceMitigate[FenceMitigate["FENCE_MITIGATE_VEL_LIMIT"] = 2] = "FENCE_MITIGATE_VEL_LIMIT";
    FenceMitigate[FenceMitigate["FENCE_MITIGATE_ENUM_END"] = 3] = "FENCE_MITIGATE_ENUM_END";
})(FenceMitigate = exports.FenceMitigate || (exports.FenceMitigate = {}));
