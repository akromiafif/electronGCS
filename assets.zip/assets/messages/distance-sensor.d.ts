import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { MavDistanceSensor } from '../enums/mav-distance-sensor';
import { MavSensorOrientation } from '../enums/mav-sensor-orientation';
export declare class DistanceSensor extends MAVLinkMessage {
    time_boot_ms: number;
    min_distance: number;
    max_distance: number;
    current_distance: number;
    type: MavDistanceSensor;
    id: number;
    orientation: MavSensorOrientation;
    covariance: number;
    horizontal_fov: number;
    vertical_fov: number;
    quaternion: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=distance-sensor.d.ts.map