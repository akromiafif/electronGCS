export declare enum MavGoto {
    MAV_GOTO_DO_HOLD = 0,
    MAV_GOTO_DO_CONTINUE = 1,
    MAV_GOTO_HOLD_AT_CURRENT_POSITION = 2,
    MAV_GOTO_HOLD_AT_SPECIFIED_POSITION = 3,
    MAV_GOTO_ENUM_END = 4
}
//# sourceMappingURL=mav-goto.d.ts.map