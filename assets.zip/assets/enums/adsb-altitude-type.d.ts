export declare enum AdsbAltitudeType {
    ADSB_ALTITUDE_TYPE_PRESSURE_QNH = 0,
    ADSB_ALTITUDE_TYPE_GEOMETRIC = 1,
    ADSB_ALTITUDE_TYPE_ENUM_END = 2
}
//# sourceMappingURL=adsb-altitude-type.d.ts.map