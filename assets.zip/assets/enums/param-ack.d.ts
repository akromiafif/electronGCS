export declare enum ParamAck {
    PARAM_ACK_ACCEPTED = 0,
    PARAM_ACK_VALUE_UNSUPPORTED = 1,
    PARAM_ACK_FAILED = 2,
    PARAM_ACK_IN_PROGRESS = 3,
    PARAM_ACK_ENUM_END = 4
}
//# sourceMappingURL=param-ack.d.ts.map