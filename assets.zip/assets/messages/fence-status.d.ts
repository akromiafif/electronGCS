import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { FenceBreach } from '../enums/fence-breach';
import { FenceMitigate } from '../enums/fence-mitigate';
export declare class FenceStatus extends MAVLinkMessage {
    breach_status: number;
    breach_count: number;
    breach_type: FenceBreach;
    breach_time: number;
    breach_mitigation: FenceMitigate;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=fence-status.d.ts.map