import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { CameraCapFlags } from '../enums/camera-cap-flags';
export declare class CameraInformation extends MAVLinkMessage {
    time_boot_ms: number;
    vendor_name: number;
    model_name: number;
    firmware_version: number;
    focal_length: number;
    sensor_size_h: number;
    sensor_size_v: number;
    resolution_h: number;
    resolution_v: number;
    lens_id: number;
    flags: CameraCapFlags;
    cam_definition_version: number;
    cam_definition_uri: string;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=camera-information.d.ts.map