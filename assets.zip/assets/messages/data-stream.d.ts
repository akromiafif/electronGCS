import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class DataStream extends MAVLinkMessage {
    stream_id: number;
    message_rate: number;
    on_off: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=data-stream.d.ts.map