export declare enum UavcanNodeHealth {
    UAVCAN_NODE_HEALTH_OK = 0,
    UAVCAN_NODE_HEALTH_WARNING = 1,
    UAVCAN_NODE_HEALTH_ERROR = 2,
    UAVCAN_NODE_HEALTH_CRITICAL = 3,
    UAVCAN_NODE_HEALTH_ENUM_END = 4
}
//# sourceMappingURL=uavcan-node-health.d.ts.map