import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { MavType } from '../enums/mav-type';
import { MavAutopilot } from '../enums/mav-autopilot';
import { MavModeFlag } from '../enums/mav-mode-flag';
import { MavState } from '../enums/mav-state';
export declare class Heartbeat extends MAVLinkMessage {
    type: MavType;
    autopilot: MavAutopilot;
    base_mode: MavModeFlag;
    custom_mode: number;
    system_status: MavState;
    mavlink_version: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=heartbeat.d.ts.map