import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { MavCmd } from '../enums/mav-cmd';
export declare class CommandLong extends MAVLinkMessage {
    target_system: number;
    target_component: number;
    command: MavCmd;
    confirmation: number;
    param1: number;
    param2: number;
    param3: number;
    param4: number;
    param5: number;
    param6: number;
    param7: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=command-long.d.ts.map