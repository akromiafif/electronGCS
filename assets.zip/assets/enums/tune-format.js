"use strict";
exports.__esModule = true;
exports.TuneFormat = void 0;
var TuneFormat;
(function (TuneFormat) {
    TuneFormat[TuneFormat["TUNE_FORMAT_QBASIC1_1"] = 1] = "TUNE_FORMAT_QBASIC1_1";
    TuneFormat[TuneFormat["TUNE_FORMAT_MML_MODERN"] = 2] = "TUNE_FORMAT_MML_MODERN";
    TuneFormat[TuneFormat["TUNE_FORMAT_ENUM_END"] = 3] = "TUNE_FORMAT_ENUM_END";
})(TuneFormat = exports.TuneFormat || (exports.TuneFormat = {}));
