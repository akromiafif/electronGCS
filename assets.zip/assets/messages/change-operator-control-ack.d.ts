import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class ChangeOperatorControlAck extends MAVLinkMessage {
    gcs_system_id: number;
    control_request: number;
    ack: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=change-operator-control-ack.d.ts.map