export declare enum CellularNetworkRadioType {
    CELLULAR_NETWORK_RADIO_TYPE_NONE = 0,
    CELLULAR_NETWORK_RADIO_TYPE_GSM = 1,
    CELLULAR_NETWORK_RADIO_TYPE_CDMA = 2,
    CELLULAR_NETWORK_RADIO_TYPE_WCDMA = 3,
    CELLULAR_NETWORK_RADIO_TYPE_LTE = 4,
    CELLULAR_NETWORK_RADIO_TYPE_ENUM_END = 5
}
//# sourceMappingURL=cellular-network-radio-type.d.ts.map