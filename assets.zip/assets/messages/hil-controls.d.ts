import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { MavMode } from '../enums/mav-mode';
export declare class HilControls extends MAVLinkMessage {
    time_usec: number;
    roll_ailerons: number;
    pitch_elevator: number;
    yaw_rudder: number;
    throttle: number;
    aux1: number;
    aux2: number;
    aux3: number;
    aux4: number;
    mode: MavMode;
    nav_mode: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=hil-controls.d.ts.map