import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class ActuatorControlTarget extends MAVLinkMessage {
    time_usec: number;
    group_mlx: number;
    controls: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=actuator-control-target.d.ts.map