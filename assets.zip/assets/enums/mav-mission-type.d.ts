export declare enum MavMissionType {
    MAV_MISSION_TYPE_MISSION = 0,
    MAV_MISSION_TYPE_FENCE = 1,
    MAV_MISSION_TYPE_RALLY = 2,
    MAV_MISSION_TYPE_ALL = 255,
    MAV_MISSION_TYPE_ENUM_END = 256
}
//# sourceMappingURL=mav-mission-type.d.ts.map