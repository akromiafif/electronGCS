import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class ChangeOperatorControl extends MAVLinkMessage {
    target_system: number;
    control_request: number;
    version: number;
    passkey: string;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=change-operator-control.d.ts.map