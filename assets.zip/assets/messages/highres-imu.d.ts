import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class HighresImu extends MAVLinkMessage {
    time_usec: number;
    xacc: number;
    yacc: number;
    zacc: number;
    xgyro: number;
    ygyro: number;
    zgyro: number;
    xmag: number;
    ymag: number;
    zmag: number;
    abs_pressure: number;
    diff_pressure: number;
    pressure_alt: number;
    temperature: number;
    fields_updated: number;
    id: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=highres-imu.d.ts.map