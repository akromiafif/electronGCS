export declare enum ParachuteAction {
    PARACHUTE_DISABLE = 0,
    PARACHUTE_ENABLE = 1,
    PARACHUTE_RELEASE = 2,
    PARACHUTE_ACTION_ENUM_END = 3
}
//# sourceMappingURL=parachute-action.d.ts.map