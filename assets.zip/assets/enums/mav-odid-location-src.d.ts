export declare enum MavOdidLocationSrc {
    MAV_ODID_LOCATION_SRC_TAKEOFF = 0,
    MAV_ODID_LOCATION_SRC_LIVE_GNSS = 1,
    MAV_ODID_LOCATION_SRC_FIXED = 2,
    MAV_ODID_LOCATION_SRC_ENUM_END = 3
}
//# sourceMappingURL=mav-odid-location-src.d.ts.map