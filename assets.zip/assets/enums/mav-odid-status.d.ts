export declare enum MavOdidStatus {
    MAV_ODID_STATUS_UNDECLARED = 0,
    MAV_ODID_STATUS_GROUND = 1,
    MAV_ODID_STATUS_AIRBORNE = 2,
    MAV_ODID_STATUS_ENUM_END = 3
}
//# sourceMappingURL=mav-odid-status.d.ts.map