export declare enum PrecisionLandMode {
    PRECISION_LAND_MODE_DISABLED = 0,
    PRECISION_LAND_MODE_OPPORTUNISTIC = 1,
    PRECISION_LAND_MODE_REQUIRED = 2,
    PRECISION_LAND_MODE_ENUM_END = 3
}
//# sourceMappingURL=precision-land-mode.d.ts.map