import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class AttitudeQuaternionCov extends MAVLinkMessage {
    time_usec: number;
    q: number;
    rollspeed: number;
    pitchspeed: number;
    yawspeed: number;
    covariance: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=attitude-quaternion-cov.d.ts.map