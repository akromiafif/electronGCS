export declare enum MavlinkDataStreamType {
    MAVLINK_DATA_STREAM_IMG_JPEG = 1,
    MAVLINK_DATA_STREAM_IMG_BMP = 2,
    MAVLINK_DATA_STREAM_IMG_RAW8U = 3,
    MAVLINK_DATA_STREAM_IMG_RAW32U = 4,
    MAVLINK_DATA_STREAM_IMG_PGM = 5,
    MAVLINK_DATA_STREAM_IMG_PNG = 6,
    MAVLINK_DATA_STREAM_TYPE_ENUM_END = 7
}
//# sourceMappingURL=mavlink-data-stream-type.d.ts.map