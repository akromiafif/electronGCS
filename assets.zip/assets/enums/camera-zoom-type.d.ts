export declare enum CameraZoomType {
    ZOOM_TYPE_STEP = 0,
    ZOOM_TYPE_CONTINUOUS = 1,
    ZOOM_TYPE_RANGE = 2,
    ZOOM_TYPE_FOCAL_LENGTH = 3,
    CAMERA_ZOOM_TYPE_ENUM_END = 4
}
//# sourceMappingURL=camera-zoom-type.d.ts.map