export enum FenceMitigate {
	FENCE_MITIGATE_UNKNOWN = 0, // Unknown
	FENCE_MITIGATE_NONE = 1, // No actions being taken
	FENCE_MITIGATE_VEL_LIMIT = 2, // Velocity limiting active to prevent breach
	FENCE_MITIGATE_ENUM_END = 3, // 
}