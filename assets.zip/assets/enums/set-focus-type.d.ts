export declare enum SetFocusType {
    FOCUS_TYPE_STEP = 0,
    FOCUS_TYPE_CONTINUOUS = 1,
    FOCUS_TYPE_RANGE = 2,
    FOCUS_TYPE_METERS = 3,
    SET_FOCUS_TYPE_ENUM_END = 4
}
//# sourceMappingURL=set-focus-type.d.ts.map