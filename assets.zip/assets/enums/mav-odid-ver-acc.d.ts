export declare enum MavOdidVerAcc {
    MAV_ODID_VER_ACC_UNKNOWN = 0,
    MAV_ODID_VER_ACC_150_METER = 1,
    MAV_ODID_VER_ACC_45_METER = 2,
    MAV_ODID_VER_ACC_25_METER = 3,
    MAV_ODID_VER_ACC_10_METER = 4,
    MAV_ODID_VER_ACC_3_METER = 5,
    MAV_ODID_VER_ACC_1_METER = 6,
    MAV_ODID_VER_ACC_ENUM_END = 7
}
//# sourceMappingURL=mav-odid-ver-acc.d.ts.map