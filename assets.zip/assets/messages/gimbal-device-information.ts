import {MAVLinkMessage} from '@ifrunistuttgart/node-mavlink';
import {readInt64LE, readUInt64LE} from '@ifrunistuttgart/node-mavlink';
import {GimbalDeviceCapFlags} from '../enums/gimbal-device-cap-flags';
/*
Information about a low level gimbal. This message should be requested by the gimbal manager or a ground station using MAV_CMD_REQUEST_MESSAGE.
*/
// time_boot_ms Timestamp (time since system boot). uint32_t
// vendor_name Name of the gimbal vendor uint8_t
// model_name Name of the gimbal model uint8_t
// firmware_version Version of the gimbal firmware (v << 24 & 0xff = Dev, v << 16 & 0xff = Patch, v << 8 & 0xff = Minor, v & 0xff = Major) uint32_t
// cap_flags Bitmap of gimbal capability flags. uint16_t
// tilt_max Maximum tilt/pitch angle (positive: up, negative: down) float
// tilt_min Minimum tilt/pitch angle (positive: up, negative: down) float
// tilt_rate_max Maximum tilt/pitch angular rate (positive: up, negative: down) float
// pan_max Maximum pan/yaw angle (positive: to the right, negative: to the left) float
// pan_min Minimum pan/yaw angle (positive: to the right, negative: to the left) float
// pan_rate_max Minimum pan/yaw angular rate (positive: to the right, negative: to the left) float
export class GimbalDeviceInformation extends MAVLinkMessage {
	public time_boot_ms!: number;
	public vendor_name!: number;
	public model_name!: number;
	public firmware_version!: number;
	public cap_flags!: GimbalDeviceCapFlags;
	public tilt_max!: number;
	public tilt_min!: number;
	public tilt_rate_max!: number;
	public pan_max!: number;
	public pan_min!: number;
	public pan_rate_max!: number;
	public _message_id: number = 283;
	public _message_name: string = 'GIMBAL_DEVICE_INFORMATION';
	public _crc_extra: number = 247;
	public _message_fields: [string, string, boolean][] = [
		['time_boot_ms', 'uint32_t', false],
		['firmware_version', 'uint32_t', false],
		['tilt_max', 'float', false],
		['tilt_min', 'float', false],
		['tilt_rate_max', 'float', false],
		['pan_max', 'float', false],
		['pan_min', 'float', false],
		['pan_rate_max', 'float', false],
		['cap_flags', 'uint16_t', false],
		['vendor_name', 'uint8_t', false],
		['model_name', 'uint8_t', false],
	];
}