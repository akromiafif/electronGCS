import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { MavCmd } from '../enums/mav-cmd';
import { MavResult } from '../enums/mav-result';
export declare class CommandAck extends MAVLinkMessage {
    command: MavCmd;
    result: MavResult;
    progress: number;
    result_param2: number;
    target_system: number;
    target_component: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=command-ack.d.ts.map