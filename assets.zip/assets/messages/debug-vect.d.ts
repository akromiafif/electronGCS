import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class DebugVect extends MAVLinkMessage {
    name: string;
    time_usec: number;
    x: number;
    y: number;
    z: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=debug-vect.d.ts.map