import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class CameraImageCaptured extends MAVLinkMessage {
    time_boot_ms: number;
    time_utc: number;
    camera_id: number;
    lat: number;
    lon: number;
    alt: number;
    relative_alt: number;
    q: number;
    image_index: number;
    capture_result: number;
    file_url: string;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=camera-image-captured.d.ts.map