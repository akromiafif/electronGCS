import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { GimbalDeviceFlags } from '../enums/gimbal-device-flags';
export declare class GimbalDeviceSetAttitude extends MAVLinkMessage {
    target_system: number;
    target_component: number;
    flags: GimbalDeviceFlags;
    q: number;
    angular_velocity_x: number;
    angular_velocity_y: number;
    angular_velocity_z: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=gimbal-device-set-attitude.d.ts.map