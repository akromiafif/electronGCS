export declare enum FirmwareVersionType {
    FIRMWARE_VERSION_TYPE_DEV = 0,
    FIRMWARE_VERSION_TYPE_ALPHA = 64,
    FIRMWARE_VERSION_TYPE_BETA = 128,
    FIRMWARE_VERSION_TYPE_RC = 192,
    FIRMWARE_VERSION_TYPE_OFFICIAL = 255,
    FIRMWARE_VERSION_TYPE_ENUM_END = 256
}
//# sourceMappingURL=firmware-version-type.d.ts.map