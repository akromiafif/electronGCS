export declare enum MavMountMode {
    MAV_MOUNT_MODE_RETRACT = 0,
    MAV_MOUNT_MODE_NEUTRAL = 1,
    MAV_MOUNT_MODE_MAVLINK_TARGETING = 2,
    MAV_MOUNT_MODE_RC_TARGETING = 3,
    MAV_MOUNT_MODE_GPS_POINT = 4,
    MAV_MOUNT_MODE_SYSID_TARGET = 5,
    MAV_MOUNT_MODE_ENUM_END = 6
}
//# sourceMappingURL=mav-mount-mode.d.ts.map