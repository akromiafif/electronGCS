import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { MavlinkDataStreamType } from '../enums/mavlink-data-stream-type';
export declare class DataTransmissionHandshake extends MAVLinkMessage {
    type: MavlinkDataStreamType;
    size: number;
    width: number;
    height: number;
    packets: number;
    payload: number;
    jpg_quality: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=data-transmission-handshake.d.ts.map