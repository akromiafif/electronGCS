export enum RcType {
	RC_TYPE_SPEKTRUM_DSM2 = 0, // Spektrum DSM2
	RC_TYPE_SPEKTRUM_DSMX = 1, // Spektrum DSMX
	RC_TYPE_ENUM_END = 2, // 
}