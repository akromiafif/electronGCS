import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class AttitudeTarget extends MAVLinkMessage {
    time_boot_ms: number;
    type_mask: number;
    q: number;
    body_roll_rate: number;
    body_pitch_rate: number;
    body_yaw_rate: number;
    thrust: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=attitude-target.d.ts.map