import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class DebugFloatArray extends MAVLinkMessage {
    time_usec: number;
    name: string;
    array_id: number;
    data: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=debug-float-array.d.ts.map