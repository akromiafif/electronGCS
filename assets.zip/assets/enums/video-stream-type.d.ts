export declare enum VideoStreamType {
    VIDEO_STREAM_TYPE_RTSP = 0,
    VIDEO_STREAM_TYPE_RTPUDP = 1,
    VIDEO_STREAM_TYPE_TCP_MPEG = 2,
    VIDEO_STREAM_TYPE_MPEG_TS_H264 = 3,
    VIDEO_STREAM_TYPE_ENUM_END = 4
}
//# sourceMappingURL=video-stream-type.d.ts.map