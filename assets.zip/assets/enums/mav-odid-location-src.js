"use strict";
exports.__esModule = true;
exports.MavOdidLocationSrc = void 0;
var MavOdidLocationSrc;
(function (MavOdidLocationSrc) {
    MavOdidLocationSrc[MavOdidLocationSrc["MAV_ODID_LOCATION_SRC_TAKEOFF"] = 0] = "MAV_ODID_LOCATION_SRC_TAKEOFF";
    MavOdidLocationSrc[MavOdidLocationSrc["MAV_ODID_LOCATION_SRC_LIVE_GNSS"] = 1] = "MAV_ODID_LOCATION_SRC_LIVE_GNSS";
    MavOdidLocationSrc[MavOdidLocationSrc["MAV_ODID_LOCATION_SRC_FIXED"] = 2] = "MAV_ODID_LOCATION_SRC_FIXED";
    MavOdidLocationSrc[MavOdidLocationSrc["MAV_ODID_LOCATION_SRC_ENUM_END"] = 3] = "MAV_ODID_LOCATION_SRC_ENUM_END";
})(MavOdidLocationSrc = exports.MavOdidLocationSrc || (exports.MavOdidLocationSrc = {}));
