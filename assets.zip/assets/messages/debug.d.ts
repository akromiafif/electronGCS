import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class Debug extends MAVLinkMessage {
    time_boot_ms: number;
    ind: number;
    value: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=debug.d.ts.map