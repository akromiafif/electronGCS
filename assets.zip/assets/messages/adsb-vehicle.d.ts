import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { AdsbAltitudeType } from '../enums/adsb-altitude-type';
import { AdsbEmitterType } from '../enums/adsb-emitter-type';
import { AdsbFlags } from '../enums/adsb-flags';
export declare class AdsbVehicle extends MAVLinkMessage {
    ICAO_address: number;
    lat: number;
    lon: number;
    altitude_type: AdsbAltitudeType;
    altitude: number;
    heading: number;
    hor_velocity: number;
    ver_velocity: number;
    callsign: string;
    emitter_type: AdsbEmitterType;
    tslc: number;
    flags: AdsbFlags;
    squawk: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=adsb-vehicle.d.ts.map