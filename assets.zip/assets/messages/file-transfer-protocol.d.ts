import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class FileTransferProtocol extends MAVLinkMessage {
    target_network: number;
    target_system: number;
    target_component: number;
    payload: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=file-transfer-protocol.d.ts.map