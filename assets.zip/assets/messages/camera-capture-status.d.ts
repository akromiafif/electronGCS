import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class CameraCaptureStatus extends MAVLinkMessage {
    time_boot_ms: number;
    image_status: number;
    video_status: number;
    image_interval: number;
    recording_time_ms: number;
    available_capacity: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=camera-capture-status.d.ts.map