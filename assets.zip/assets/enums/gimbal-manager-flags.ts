export enum GimbalManagerFlags {
	GIMBAL_MANAGER_FLAGS_RETRACT = 1, // Based on GIMBAL_DEVICE_FLAGS_RETRACT
	GIMBAL_MANAGER_FLAGS_NEUTRAL = 2, // Based on GIMBAL_DEVICE_FLAGS_NEUTRAL
	GIMBAL_MANAGER_FLAGS_ROLL_LOCK = 4, // Based on GIMBAL_DEVICE_FLAGS_ROLL_LOCK
	GIMBAL_MANAGER_FLAGS_PITCH_LOCK = 8, // Based on GIMBAL_DEVICE_FLAGS_PITCH_LOCK
	GIMBAL_MANAGER_FLAGS_YAW_LOCK = 16, // Based on GIMBAL_DEVICE_FLAGS_YAW_LOCK
	GIMBAL_MANAGER_FLAGS_ANGULAR_VELOCITY_RELATIVE_TO_FOCAL_LENGTH = 1048576, // Scale angular velocity relative to focal length. This means the gimbal moves slower if it is zoomed in.
	GIMBAL_MANAGER_FLAGS_NUDGE = 2097152, // Interpret attitude control on top of pointing to a location or tracking. If this flag is set, the quaternion is relative to the existing tracking angle.
	GIMBAL_MANAGER_FLAGS_OVERRIDE = 4194304, // Completely override pointing to a location or tracking. If this flag is set, the quaternion is (as usual) according to GIMBAL_MANAGER_FLAGS_YAW_LOCK.
	GIMBAL_MANAGER_FLAGS_ENUM_END = 4194305, // 
}