"use strict";
exports.__esModule = true;
exports.MavOdidDescType = void 0;
var MavOdidDescType;
(function (MavOdidDescType) {
    MavOdidDescType[MavOdidDescType["MAV_ODID_DESC_TYPE_TEXT"] = 0] = "MAV_ODID_DESC_TYPE_TEXT";
    MavOdidDescType[MavOdidDescType["MAV_ODID_DESC_TYPE_ENUM_END"] = 1] = "MAV_ODID_DESC_TYPE_ENUM_END";
})(MavOdidDescType = exports.MavOdidDescType || (exports.MavOdidDescType = {}));
