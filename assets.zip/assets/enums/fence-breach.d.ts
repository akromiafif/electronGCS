export declare enum FenceBreach {
    FENCE_BREACH_NONE = 0,
    FENCE_BREACH_MINALT = 1,
    FENCE_BREACH_MAXALT = 2,
    FENCE_BREACH_BOUNDARY = 3,
    FENCE_BREACH_ENUM_END = 4
}
//# sourceMappingURL=fence-breach.d.ts.map