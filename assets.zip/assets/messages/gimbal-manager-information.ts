import {MAVLinkMessage} from '@ifrunistuttgart/node-mavlink';
import {readInt64LE, readUInt64LE} from '@ifrunistuttgart/node-mavlink';
import {GimbalManagerCapFlags} from '../enums/gimbal-manager-cap-flags';
/*
Information about a high level gimbal manager. This message should be requested by a ground station using MAV_CMD_REQUEST_MESSAGE.
*/
// time_boot_ms Timestamp (time since system boot). uint32_t
// cap_flags Bitmap of gimbal capability flags. uint32_t
// gimbal_component Gimbal component ID that this gimbal manager is responsible for. uint8_t
// tilt_max Maximum tilt/pitch angle (positive: up, negative: down) float
// tilt_min Minimum tilt/pitch angle (positive: up, negative: down) float
// tilt_rate_max Maximum tilt/pitch angular rate (positive: up, negative: down) float
// pan_max Maximum pan/yaw angle (positive: to the right, negative: to the left) float
// pan_min Minimum pan/yaw angle (positive: to the right, negative: to the left) float
// pan_rate_max Minimum pan/yaw angular rate (positive: to the right, negative: to the left) float
export class GimbalManagerInformation extends MAVLinkMessage {
	public time_boot_ms!: number;
	public cap_flags!: GimbalManagerCapFlags;
	public gimbal_component!: number;
	public tilt_max!: number;
	public tilt_min!: number;
	public tilt_rate_max!: number;
	public pan_max!: number;
	public pan_min!: number;
	public pan_rate_max!: number;
	public _message_id: number = 280;
	public _message_name: string = 'GIMBAL_MANAGER_INFORMATION';
	public _crc_extra: number = 128;
	public _message_fields: [string, string, boolean][] = [
		['time_boot_ms', 'uint32_t', false],
		['cap_flags', 'uint32_t', false],
		['tilt_max', 'float', false],
		['tilt_min', 'float', false],
		['tilt_rate_max', 'float', false],
		['pan_max', 'float', false],
		['pan_min', 'float', false],
		['pan_rate_max', 'float', false],
		['gimbal_component', 'uint8_t', false],
	];
}