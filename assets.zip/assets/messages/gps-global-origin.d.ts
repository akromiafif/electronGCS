import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class GpsGlobalOrigin extends MAVLinkMessage {
    latitude: number;
    longitude: number;
    altitude: number;
    time_usec: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=gps-global-origin.d.ts.map