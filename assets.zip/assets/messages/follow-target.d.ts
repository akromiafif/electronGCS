import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class FollowTarget extends MAVLinkMessage {
    timestamp: number;
    est_capabilities: number;
    lat: number;
    lon: number;
    alt: number;
    vel: number;
    acc: number;
    attitude_q: number;
    rates: number;
    position_cov: number;
    custom_state: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=follow-target.d.ts.map