export declare enum SerialControlFlag {
    SERIAL_CONTROL_FLAG_REPLY = 1,
    SERIAL_CONTROL_FLAG_RESPOND = 2,
    SERIAL_CONTROL_FLAG_EXCLUSIVE = 4,
    SERIAL_CONTROL_FLAG_BLOCKING = 8,
    SERIAL_CONTROL_FLAG_MULTI = 16,
    SERIAL_CONTROL_FLAG_ENUM_END = 17
}
//# sourceMappingURL=serial-control-flag.d.ts.map