import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class Attitude extends MAVLinkMessage {
    time_boot_ms: number;
    roll: number;
    pitch: number;
    yaw: number;
    rollspeed: number;
    pitchspeed: number;
    yawspeed: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=attitude.d.ts.map