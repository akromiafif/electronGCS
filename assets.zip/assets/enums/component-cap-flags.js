"use strict";
exports.__esModule = true;
exports.ComponentCapFlags = void 0;
var ComponentCapFlags;
(function (ComponentCapFlags) {
    ComponentCapFlags[ComponentCapFlags["COMPONENT_CAP_FLAGS_PARAM"] = 1] = "COMPONENT_CAP_FLAGS_PARAM";
    ComponentCapFlags[ComponentCapFlags["COMPONENT_CAP_FLAGS_PARAM_EXT"] = 2] = "COMPONENT_CAP_FLAGS_PARAM_EXT";
    ComponentCapFlags[ComponentCapFlags["COMPONENT_CAP_FLAGS_ENUM_END"] = 3] = "COMPONENT_CAP_FLAGS_ENUM_END";
})(ComponentCapFlags = exports.ComponentCapFlags || (exports.ComponentCapFlags = {}));
