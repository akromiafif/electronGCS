import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class GlobalPositionInt extends MAVLinkMessage {
    time_boot_ms: number;
    lat: number;
    lon: number;
    alt: number;
    relative_alt: number;
    vx: number;
    vy: number;
    vz: number;
    hdg: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=global-position-int.d.ts.map