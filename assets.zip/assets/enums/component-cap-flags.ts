export enum ComponentCapFlags {
	COMPONENT_CAP_FLAGS_PARAM = 1, // Component has parameters, and supports the parameter protocol (PARAM messages).
	COMPONENT_CAP_FLAGS_PARAM_EXT = 2, // Component has parameters, and supports the extended parameter protocol (PARAM_EXT messages).
	COMPONENT_CAP_FLAGS_ENUM_END = 3, // 
}