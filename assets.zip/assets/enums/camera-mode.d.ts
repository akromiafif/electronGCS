export declare enum CameraMode {
    CAMERA_MODE_IMAGE = 0,
    CAMERA_MODE_VIDEO = 1,
    CAMERA_MODE_IMAGE_SURVEY = 2,
    CAMERA_MODE_ENUM_END = 3
}
//# sourceMappingURL=camera-mode.d.ts.map