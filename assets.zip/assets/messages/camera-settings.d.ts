import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { CameraMode } from '../enums/camera-mode';
export declare class CameraSettings extends MAVLinkMessage {
    time_boot_ms: number;
    mode_id: CameraMode;
    zoomLevel: number;
    focusLevel: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=camera-settings.d.ts.map