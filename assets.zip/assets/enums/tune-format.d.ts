export declare enum TuneFormat {
    TUNE_FORMAT_QBASIC1_1 = 1,
    TUNE_FORMAT_MML_MODERN = 2,
    TUNE_FORMAT_ENUM_END = 3
}
//# sourceMappingURL=tune-format.d.ts.map