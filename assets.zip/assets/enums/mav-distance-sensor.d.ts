export declare enum MavDistanceSensor {
    MAV_DISTANCE_SENSOR_LASER = 0,
    MAV_DISTANCE_SENSOR_ULTRASOUND = 1,
    MAV_DISTANCE_SENSOR_INFRARED = 2,
    MAV_DISTANCE_SENSOR_RADAR = 3,
    MAV_DISTANCE_SENSOR_UNKNOWN = 4,
    MAV_DISTANCE_SENSOR_ENUM_END = 5
}
//# sourceMappingURL=mav-distance-sensor.d.ts.map