export declare enum MavDoRepositionFlags {
    MAV_DO_REPOSITION_FLAGS_CHANGE_MODE = 1,
    MAV_DO_REPOSITION_FLAGS_ENUM_END = 2
}
//# sourceMappingURL=mav-do-reposition-flags.d.ts.map