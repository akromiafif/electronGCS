import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { MavType } from '../enums/mav-type';
import { MavAutopilot } from '../enums/mav-autopilot';
import { HlFailureFlag } from '../enums/hl-failure-flag';
export declare class HighLatency2 extends MAVLinkMessage {
    timestamp: number;
    type: MavType;
    autopilot: MavAutopilot;
    custom_mode: number;
    latitude: number;
    longitude: number;
    altitude: number;
    target_altitude: number;
    heading: number;
    target_heading: number;
    target_distance: number;
    throttle: number;
    airspeed: number;
    airspeed_sp: number;
    groundspeed: number;
    windspeed: number;
    wind_heading: number;
    eph: number;
    epv: number;
    temperature_air: number;
    climb_rate: number;
    battery: number;
    wp_num: number;
    failure_flags: HlFailureFlag;
    custom0: number;
    custom1: number;
    custom2: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=high-latency2.d.ts.map