import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { CellularNetworkStatusFlag } from '../enums/cellular-network-status-flag';
import { CellularNetworkRadioType } from '../enums/cellular-network-radio-type';
export declare class CellularStatus extends MAVLinkMessage {
    status: CellularNetworkStatusFlag;
    type: CellularNetworkRadioType;
    quality: number;
    mcc: number;
    mnc: number;
    lac: number;
    cid: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=cellular-status.d.ts.map