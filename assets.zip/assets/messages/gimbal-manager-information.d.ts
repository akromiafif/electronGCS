import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { GimbalManagerCapFlags } from '../enums/gimbal-manager-cap-flags';
export declare class GimbalManagerInformation extends MAVLinkMessage {
    time_boot_ms: number;
    cap_flags: GimbalManagerCapFlags;
    gimbal_component: number;
    tilt_max: number;
    tilt_min: number;
    tilt_rate_max: number;
    pan_max: number;
    pan_min: number;
    pan_rate_max: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=gimbal-manager-information.d.ts.map