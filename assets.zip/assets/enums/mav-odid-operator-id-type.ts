export enum MavOdidOperatorIdType {
	MAV_ODID_OPERATOR_ID_TYPE_CAA = 0, // CAA (Civil Aviation Authority) registered operator ID.
	MAV_ODID_OPERATOR_ID_TYPE_ENUM_END = 1, // 
}