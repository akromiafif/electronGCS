import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class GlobalVisionPositionEstimate extends MAVLinkMessage {
    usec: number;
    x: number;
    y: number;
    z: number;
    roll: number;
    pitch: number;
    yaw: number;
    covariance: number;
    reset_counter: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=global-vision-position-estimate.d.ts.map