export declare enum MavVtolState {
    MAV_VTOL_STATE_UNDEFINED = 0,
    MAV_VTOL_STATE_TRANSITION_TO_FW = 1,
    MAV_VTOL_STATE_TRANSITION_TO_MC = 2,
    MAV_VTOL_STATE_MC = 3,
    MAV_VTOL_STATE_FW = 4,
    MAV_VTOL_STATE_ENUM_END = 5
}
//# sourceMappingURL=mav-vtol-state.d.ts.map