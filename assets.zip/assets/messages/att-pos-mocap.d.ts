import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class AttPosMocap extends MAVLinkMessage {
    time_usec: number;
    q: number;
    x: number;
    y: number;
    z: number;
    covariance: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=att-pos-mocap.d.ts.map