export declare enum LandingTargetType {
    LANDING_TARGET_TYPE_LIGHT_BEACON = 0,
    LANDING_TARGET_TYPE_RADIO_BEACON = 1,
    LANDING_TARGET_TYPE_VISION_FIDUCIAL = 2,
    LANDING_TARGET_TYPE_VISION_OTHER = 3,
    LANDING_TARGET_TYPE_ENUM_END = 4
}
//# sourceMappingURL=landing-target-type.d.ts.map