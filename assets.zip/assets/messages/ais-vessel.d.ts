import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { AisNavStatus } from '../enums/ais-nav-status';
import { AisType } from '../enums/ais-type';
import { AisFlags } from '../enums/ais-flags';
export declare class AisVessel extends MAVLinkMessage {
    MMSI: number;
    lat: number;
    lon: number;
    COG: number;
    heading: number;
    velocity: number;
    turn_rate: number;
    navigational_status: AisNavStatus;
    type: AisType;
    dimension_bow: number;
    dimension_stern: number;
    dimension_port: number;
    dimension_starboard: number;
    callsign: string;
    name: string;
    tslc: number;
    flags: AisFlags;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=ais-vessel.d.ts.map