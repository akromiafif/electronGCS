export declare enum MavBatteryFunction {
    MAV_BATTERY_FUNCTION_UNKNOWN = 0,
    MAV_BATTERY_FUNCTION_ALL = 1,
    MAV_BATTERY_FUNCTION_PROPULSION = 2,
    MAV_BATTERY_FUNCTION_AVIONICS = 3,
    MAV_BATTERY_TYPE_PAYLOAD = 4,
    MAV_BATTERY_FUNCTION_ENUM_END = 5
}
//# sourceMappingURL=mav-battery-function.d.ts.map