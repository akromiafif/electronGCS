import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class HilOpticalFlow extends MAVLinkMessage {
    time_usec: number;
    sensor_id: number;
    integration_time_us: number;
    integrated_x: number;
    integrated_y: number;
    integrated_xgyro: number;
    integrated_ygyro: number;
    integrated_zgyro: number;
    temperature: number;
    quality: number;
    time_delta_distance_us: number;
    distance: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=hil-optical-flow.d.ts.map