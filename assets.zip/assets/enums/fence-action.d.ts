export declare enum FenceAction {
    FENCE_ACTION_NONE = 0,
    FENCE_ACTION_GUIDED = 1,
    FENCE_ACTION_REPORT = 2,
    FENCE_ACTION_GUIDED_THR_PASS = 3,
    FENCE_ACTION_RTL = 4,
    FENCE_ACTION_ENUM_END = 5
}
//# sourceMappingURL=fence-action.d.ts.map