"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
exports.ComponentInformation = void 0;
var node_mavlink_1 = require("@ifrunistuttgart/node-mavlink");
/*
Information about a component. For camera components instead use CAMERA_INFORMATION, and for autopilots use AUTOPILOT_VERSION. Components including GCSes should consider supporting requests of this message via MAV_CMD_REQUEST_MESSAGE.
*/
// time_boot_ms Timestamp (time since system boot). uint32_t
// vendor_name Name of the component vendor uint8_t
// model_name Name of the component model uint8_t
// firmware_version Version of the component firmware (v << 24 & 0xff = Dev, v << 16 & 0xff = Patch, v << 8 & 0xff = Minor, v & 0xff = Major) uint32_t
// hardware_version Version of the component hardware (v << 24 & 0xff = Dev, v << 16 & 0xff = Patch, v << 8 & 0xff = Minor, v & 0xff = Major) uint32_t
// capability_flags Bitmap of component capability flags. uint32_t
// component_definition_version Component definition version (iteration) uint16_t
// component_definition_uri Component definition URI (if any, otherwise only basic functions will be available). The XML format is not yet specified and work in progress. char
var ComponentInformation = /** @class */ (function (_super) {
    __extends(ComponentInformation, _super);
    function ComponentInformation() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._message_id = 395;
        _this._message_name = 'COMPONENT_INFORMATION';
        _this._crc_extra = 231;
        _this._message_fields = [
            ['time_boot_ms', 'uint32_t', false],
            ['firmware_version', 'uint32_t', false],
            ['hardware_version', 'uint32_t', false],
            ['capability_flags', 'uint32_t', false],
            ['component_definition_version', 'uint16_t', false],
            ['vendor_name', 'uint8_t', false],
            ['model_name', 'uint8_t', false],
            ['component_definition_uri', 'char', false],
        ];
        return _this;
    }
    return ComponentInformation;
}(node_mavlink_1.MAVLinkMessage));
exports.ComponentInformation = ComponentInformation;
