import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class ControlSystemState extends MAVLinkMessage {
    time_usec: number;
    x_acc: number;
    y_acc: number;
    z_acc: number;
    x_vel: number;
    y_vel: number;
    z_vel: number;
    x_pos: number;
    y_pos: number;
    z_pos: number;
    airspeed: number;
    vel_variance: number;
    pos_variance: number;
    q: number;
    roll_rate: number;
    pitch_rate: number;
    yaw_rate: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=control-system-state.d.ts.map