import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class HilGps extends MAVLinkMessage {
    time_usec: number;
    fix_type: number;
    lat: number;
    lon: number;
    alt: number;
    eph: number;
    epv: number;
    vel: number;
    vn: number;
    ve: number;
    vd: number;
    cog: number;
    satellites_visible: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=hil-gps.d.ts.map