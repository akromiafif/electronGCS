export declare enum StorageStatus {
    STORAGE_STATUS_EMPTY = 0,
    STORAGE_STATUS_UNFORMATTED = 1,
    STORAGE_STATUS_READY = 2,
    STORAGE_STATUS_NOT_SUPPORTED = 3,
    STORAGE_STATUS_ENUM_END = 4
}
//# sourceMappingURL=storage-status.d.ts.map