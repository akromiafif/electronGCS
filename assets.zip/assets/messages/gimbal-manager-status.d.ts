import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { GimbalManagerFlags } from '../enums/gimbal-manager-flags';
export declare class GimbalManagerStatus extends MAVLinkMessage {
    time_boot_ms: number;
    flags: GimbalManagerFlags;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=gimbal-manager-status.d.ts.map