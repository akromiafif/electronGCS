import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { RtkBaselineCoordinateSystem } from '../enums/rtk-baseline-coordinate-system';
export declare class GpsRtk extends MAVLinkMessage {
    time_last_baseline_ms: number;
    rtk_receiver_id: number;
    wn: number;
    tow: number;
    rtk_health: number;
    rtk_rate: number;
    nsats: number;
    baseline_coords_type: RtkBaselineCoordinateSystem;
    baseline_a_mm: number;
    baseline_b_mm: number;
    baseline_c_mm: number;
    accuracy: number;
    iar_num_hypotheses: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=gps-rtk.d.ts.map