export declare enum CellularNetworkStatusFlag {
    CELLULAR_NETWORK_STATUS_FLAG_ROAMING = 1,
    CELLULAR_NETWORK_STATUS_FLAG_ENUM_END = 2
}
//# sourceMappingURL=cellular-network-status-flag.d.ts.map