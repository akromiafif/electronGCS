import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { ComponentCapFlags } from '../enums/component-cap-flags';
export declare class ComponentInformation extends MAVLinkMessage {
    time_boot_ms: number;
    vendor_name: number;
    model_name: number;
    firmware_version: number;
    hardware_version: number;
    capability_flags: ComponentCapFlags;
    component_definition_version: number;
    component_definition_uri: string;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=component-information.d.ts.map