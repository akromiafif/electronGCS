import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class AutopilotStateForGimbalDevice extends MAVLinkMessage {
    time_boot_us: number;
    target_system: number;
    target_component: number;
    q: number;
    q_estimated_delay_us: number;
    vx: number;
    vy: number;
    vz: number;
    v_estimated_delay_us: number;
    feed_forward_angular_velocity_z: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=autopilot-state-for-gimbal-device.d.ts.map