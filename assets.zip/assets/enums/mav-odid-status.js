"use strict";
exports.__esModule = true;
exports.MavOdidStatus = void 0;
var MavOdidStatus;
(function (MavOdidStatus) {
    MavOdidStatus[MavOdidStatus["MAV_ODID_STATUS_UNDECLARED"] = 0] = "MAV_ODID_STATUS_UNDECLARED";
    MavOdidStatus[MavOdidStatus["MAV_ODID_STATUS_GROUND"] = 1] = "MAV_ODID_STATUS_GROUND";
    MavOdidStatus[MavOdidStatus["MAV_ODID_STATUS_AIRBORNE"] = 2] = "MAV_ODID_STATUS_AIRBORNE";
    MavOdidStatus[MavOdidStatus["MAV_ODID_STATUS_ENUM_END"] = 3] = "MAV_ODID_STATUS_ENUM_END";
})(MavOdidStatus = exports.MavOdidStatus || (exports.MavOdidStatus = {}));
