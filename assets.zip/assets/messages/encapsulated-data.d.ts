import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class EncapsulatedData extends MAVLinkMessage {
    seqnr: number;
    data: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=encapsulated-data.d.ts.map