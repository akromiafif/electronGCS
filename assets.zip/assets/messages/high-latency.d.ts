import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { MavModeFlag } from '../enums/mav-mode-flag';
import { MavLandedState } from '../enums/mav-landed-state';
import { GpsFixType } from '../enums/gps-fix-type';
export declare class HighLatency extends MAVLinkMessage {
    base_mode: MavModeFlag;
    custom_mode: number;
    landed_state: MavLandedState;
    roll: number;
    pitch: number;
    heading: number;
    throttle: number;
    heading_sp: number;
    latitude: number;
    longitude: number;
    altitude_amsl: number;
    altitude_sp: number;
    airspeed: number;
    airspeed_sp: number;
    groundspeed: number;
    climb_rate: number;
    gps_nsat: number;
    gps_fix_type: GpsFixType;
    battery_remaining: number;
    temperature: number;
    temperature_air: number;
    failsafe: number;
    wp_num: number;
    wp_distance: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=high-latency.d.ts.map