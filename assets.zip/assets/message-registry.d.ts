import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare const messageRegistry: Array<[number, new (system_id: number, component_id: number) => MAVLinkMessage]>;
//# sourceMappingURL=message-registry.d.ts.map