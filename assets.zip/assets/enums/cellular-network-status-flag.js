"use strict";
exports.__esModule = true;
exports.CellularNetworkStatusFlag = void 0;
var CellularNetworkStatusFlag;
(function (CellularNetworkStatusFlag) {
    CellularNetworkStatusFlag[CellularNetworkStatusFlag["CELLULAR_NETWORK_STATUS_FLAG_ROAMING"] = 1] = "CELLULAR_NETWORK_STATUS_FLAG_ROAMING";
    CellularNetworkStatusFlag[CellularNetworkStatusFlag["CELLULAR_NETWORK_STATUS_FLAG_ENUM_END"] = 2] = "CELLULAR_NETWORK_STATUS_FLAG_ENUM_END";
})(CellularNetworkStatusFlag = exports.CellularNetworkStatusFlag || (exports.CellularNetworkStatusFlag = {}));
