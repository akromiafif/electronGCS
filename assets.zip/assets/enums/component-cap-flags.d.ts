export declare enum ComponentCapFlags {
    COMPONENT_CAP_FLAGS_PARAM = 1,
    COMPONENT_CAP_FLAGS_PARAM_EXT = 2,
    COMPONENT_CAP_FLAGS_ENUM_END = 3
}
//# sourceMappingURL=component-cap-flags.d.ts.map