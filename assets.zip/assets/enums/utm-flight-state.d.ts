export declare enum UtmFlightState {
    UTM_FLIGHT_STATE_UNKNOWN = 1,
    UTM_FLIGHT_STATE_GROUND = 2,
    UTM_FLIGHT_STATE_AIRBORNE = 3,
    UTM_FLIGHT_STATE_EMERGENCY = 16,
    UTM_FLIGHT_STATE_NOCTRL = 32,
    UTM_FLIGHT_STATE_ENUM_END = 33
}
//# sourceMappingURL=utm-flight-state.d.ts.map