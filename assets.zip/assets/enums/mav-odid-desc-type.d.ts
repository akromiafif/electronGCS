export declare enum MavOdidDescType {
    MAV_ODID_DESC_TYPE_TEXT = 0,
    MAV_ODID_DESC_TYPE_ENUM_END = 1
}
//# sourceMappingURL=mav-odid-desc-type.d.ts.map