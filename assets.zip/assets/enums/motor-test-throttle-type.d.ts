export declare enum MotorTestThrottleType {
    MOTOR_TEST_THROTTLE_PERCENT = 0,
    MOTOR_TEST_THROTTLE_PWM = 1,
    MOTOR_TEST_THROTTLE_PILOT = 2,
    MOTOR_TEST_COMPASS_CAL = 3,
    MOTOR_TEST_THROTTLE_TYPE_ENUM_END = 4
}
//# sourceMappingURL=motor-test-throttle-type.d.ts.map