import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { GimbalDeviceCapFlags } from '../enums/gimbal-device-cap-flags';
export declare class GimbalDeviceInformation extends MAVLinkMessage {
    time_boot_ms: number;
    vendor_name: number;
    model_name: number;
    firmware_version: number;
    cap_flags: GimbalDeviceCapFlags;
    tilt_max: number;
    tilt_min: number;
    tilt_rate_max: number;
    pan_max: number;
    pan_min: number;
    pan_rate_max: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=gimbal-device-information.d.ts.map