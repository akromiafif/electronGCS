import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { GimbalManagerFlags } from '../enums/gimbal-manager-flags';
export declare class GimbalManagerSetAttitude extends MAVLinkMessage {
    target_system: number;
    target_component: number;
    flags: GimbalManagerFlags;
    q: number;
    angular_velocity_x: number;
    angular_velocity_y: number;
    angular_velocity_z: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=gimbal-manager-set-attitude.d.ts.map