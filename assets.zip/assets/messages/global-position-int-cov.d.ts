import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { MavEstimatorType } from '../enums/mav-estimator-type';
export declare class GlobalPositionIntCov extends MAVLinkMessage {
    time_usec: number;
    estimator_type: MavEstimatorType;
    lat: number;
    lon: number;
    alt: number;
    relative_alt: number;
    vx: number;
    vy: number;
    vz: number;
    covariance: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=global-position-int-cov.d.ts.map