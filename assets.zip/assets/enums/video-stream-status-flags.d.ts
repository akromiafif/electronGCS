export declare enum VideoStreamStatusFlags {
    VIDEO_STREAM_STATUS_FLAGS_RUNNING = 1,
    VIDEO_STREAM_STATUS_FLAGS_THERMAL = 2,
    VIDEO_STREAM_STATUS_FLAGS_ENUM_END = 3
}
//# sourceMappingURL=video-stream-status-flags.d.ts.map