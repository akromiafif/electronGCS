import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class AttitudeQuaternion extends MAVLinkMessage {
    time_boot_ms: number;
    q1: number;
    q2: number;
    q3: number;
    q4: number;
    rollspeed: number;
    pitchspeed: number;
    yawspeed: number;
    repr_offset_q: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=attitude-quaternion.d.ts.map