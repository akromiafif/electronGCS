import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { EstimatorStatusFlags } from '../enums/estimator-status-flags';
export declare class EstimatorStatus extends MAVLinkMessage {
    time_usec: number;
    flags: EstimatorStatusFlags;
    vel_ratio: number;
    pos_horiz_ratio: number;
    pos_vert_ratio: number;
    mag_ratio: number;
    hagl_ratio: number;
    tas_ratio: number;
    pos_horiz_accuracy: number;
    pos_vert_accuracy: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=estimator-status.d.ts.map