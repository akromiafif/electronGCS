import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { MavVtolState } from '../enums/mav-vtol-state';
import { MavLandedState } from '../enums/mav-landed-state';
export declare class ExtendedSysState extends MAVLinkMessage {
    vtol_state: MavVtolState;
    landed_state: MavLandedState;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=extended-sys-state.d.ts.map