import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class GpsStatus extends MAVLinkMessage {
    satellites_visible: number;
    satellite_prn: number;
    satellite_used: number;
    satellite_elevation: number;
    satellite_azimuth: number;
    satellite_snr: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=gps-status.d.ts.map