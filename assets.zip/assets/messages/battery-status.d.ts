import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { MavBatteryFunction } from '../enums/mav-battery-function';
import { MavBatteryType } from '../enums/mav-battery-type';
import { MavBatteryChargeState } from '../enums/mav-battery-charge-state';
export declare class BatteryStatus extends MAVLinkMessage {
    id: number;
    battery_function: MavBatteryFunction;
    type: MavBatteryType;
    temperature: number;
    voltages: number;
    current_battery: number;
    current_consumed: number;
    energy_consumed: number;
    battery_remaining: number;
    time_remaining: number;
    charge_state: MavBatteryChargeState;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=battery-status.d.ts.map