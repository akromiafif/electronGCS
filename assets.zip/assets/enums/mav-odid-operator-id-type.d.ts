export declare enum MavOdidOperatorIdType {
    MAV_ODID_OPERATOR_ID_TYPE_CAA = 0,
    MAV_ODID_OPERATOR_ID_TYPE_ENUM_END = 1
}
//# sourceMappingURL=mav-odid-operator-id-type.d.ts.map