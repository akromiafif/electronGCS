import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { GpsFixType } from '../enums/gps-fix-type';
export declare class GpsRawInt extends MAVLinkMessage {
    time_usec: number;
    fix_type: GpsFixType;
    lat: number;
    lon: number;
    alt: number;
    eph: number;
    epv: number;
    vel: number;
    cog: number;
    satellites_visible: number;
    alt_ellipsoid: number;
    h_acc: number;
    v_acc: number;
    vel_acc: number;
    hdg_acc: number;
    yaw: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=gps-raw-int.d.ts.map