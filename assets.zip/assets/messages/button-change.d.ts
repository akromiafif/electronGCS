import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class ButtonChange extends MAVLinkMessage {
    time_boot_ms: number;
    last_change_ms: number;
    state: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=button-change.d.ts.map