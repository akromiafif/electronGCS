import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { MavFrame } from '../enums/mav-frame';
import { MavCmd } from '../enums/mav-cmd';
export declare class CommandInt extends MAVLinkMessage {
    target_system: number;
    target_component: number;
    frame: MavFrame;
    command: MavCmd;
    current: number;
    autocontinue: number;
    param1: number;
    param2: number;
    param3: number;
    param4: number;
    x: number;
    y: number;
    z: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=command-int.d.ts.map