import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
export declare class Altitude extends MAVLinkMessage {
    time_usec: number;
    altitude_monotonic: number;
    altitude_amsl: number;
    altitude_local: number;
    altitude_relative: number;
    altitude_terrain: number;
    bottom_clearance: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=altitude.d.ts.map