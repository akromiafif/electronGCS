export declare enum RcType {
    RC_TYPE_SPEKTRUM_DSM2 = 0,
    RC_TYPE_SPEKTRUM_DSMX = 1,
    RC_TYPE_ENUM_END = 2
}
//# sourceMappingURL=rc-type.d.ts.map