import { MAVLinkMessage } from '@ifrunistuttgart/node-mavlink';
import { GpsInputIgnoreFlags } from '../enums/gps-input-ignore-flags';
export declare class GpsInput extends MAVLinkMessage {
    time_usec: number;
    gps_id: number;
    ignore_flags: GpsInputIgnoreFlags;
    time_week_ms: number;
    time_week: number;
    fix_type: number;
    lat: number;
    lon: number;
    alt: number;
    hdop: number;
    vdop: number;
    vn: number;
    ve: number;
    vd: number;
    speed_accuracy: number;
    horiz_accuracy: number;
    vert_accuracy: number;
    satellites_visible: number;
    yaw: number;
    _message_id: number;
    _message_name: string;
    _crc_extra: number;
    _message_fields: [string, string, boolean][];
}
//# sourceMappingURL=gps-input.d.ts.map