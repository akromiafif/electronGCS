export declare enum MavOdidHeightRef {
    MAV_ODID_HEIGHT_REF_OVER_TAKEOFF = 0,
    MAV_ODID_HEIGHT_REF_OVER_GROUND = 1,
    MAV_ODID_HEIGHT_REF_ENUM_END = 2
}
//# sourceMappingURL=mav-odid-height-ref.d.ts.map