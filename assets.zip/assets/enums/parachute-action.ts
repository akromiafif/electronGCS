export enum ParachuteAction {
	PARACHUTE_DISABLE = 0, // Disable parachute release.
	PARACHUTE_ENABLE = 1, // Enable parachute release.
	PARACHUTE_RELEASE = 2, // Release parachute.
	PARACHUTE_ACTION_ENUM_END = 3, // 
}